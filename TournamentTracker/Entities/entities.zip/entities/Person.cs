﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace TournamentTracker.Entities
{
    public class Person
    {
        [Required]
        [DisplayName("First Name")]
        public string FirstName { get; set; }
		[Required]
		[DisplayName("Last Name")]
		public string LastName { get; set; }
		[Required]
		[DisplayName("Email Address")]
		public string EmailAddress { get; set; }
    }
}
